export class Bot {
    bot_reply: string;
    constructor() { 
    }
 }