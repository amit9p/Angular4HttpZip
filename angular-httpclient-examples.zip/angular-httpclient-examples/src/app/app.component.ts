import { Component } from '@angular/core';

@Component({
   selector: 'app-root',
   template: `
				<app-observable></app-observable>
				
             `
})
export class AppComponent { 

}
    