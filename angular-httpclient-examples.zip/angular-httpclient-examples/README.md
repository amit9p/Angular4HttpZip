# Angular HttpClient Examples (GET, POST , UPDATE, DELETE)


## Run Fake Rest API server 

    npm install -g json-server
    json-server --watch db.json 

## Run Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

